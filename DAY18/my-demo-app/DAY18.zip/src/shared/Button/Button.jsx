import btnStyle from "./Button.module.css";
const Button = () => {
  return (
    <>
      <div className={btnStyle.btnCommon}>
          SUBMIT
      </div>
    </>
  );
};
export default Button;
